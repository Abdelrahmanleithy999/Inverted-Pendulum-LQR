clear all 
close all
clc
mp = 0.033; % mass of the pendulum
mr = 0.04; %mass of the rod ??????? ???? ?? ???????
lp = 0.08; %length of the pendulum
lr = 0.12; %length of the rod
jp = ((1/12) * mp * (lp^2)); %inertia of the pendulum
jr = ((1/3) * mr * (lr^2)); %inertia of the rod
kt = 0.1; %tourque constant of the motor
km = 0.11; %emf constant of the motor
vm = 12; %input voltage of the motor
rm = 10; %armature resistance of the motor
g=9.81; %Gravitational acceleration [m/s^2] 

%tau = kt(vm - km * thetad) / rm;

c1 = jr + (mp * (lr^2)); %?????? ???? ????????
c2 = -0.5 * mp * lr * lp;
c3 = (0.25 *  mp * (lp^2)) + jp;
c4 = -0.5 * mp * lr * lp;
c5 = -0.5 * mp * g * lp;


A = [0 , 1 , 0 , 0;
    0 , (c3*kt*km)/(rm*(c1*c3-c2*c4)) , (c2*c5)/(c1*c3-c2*c4) , 0;
    0 , 0 , 0 , 1;
    0 ,(c4*kt*km)/(rm*(c1*c3-c2*c4)) , -c5/c3 , 0];

B= [0;
    (c3*kt)/(rm*(c1*c3-c2*c4)); 
    0; 
    (c4*kt)/(rm*(c1*c3-c2*c4))
    ];

C= [1, 0, 0, 0;
    0, 0, 1, 0];
eig(A)
rank(ctrb(A,B))


%k = place(A,B,[-1,-3,-8,0]);

Q = 3*[17720 0 0 0;
    0 2 0 0;
    0 0 3 0;
    0 0 0 35]
R = 87*3


k = lqr(A,B,Q,R) 



%tspan = 0:0.0005:7;
%x0 = [ 0.3; 0;-1; 0];  % initial condition 
%wr = [0; 0; 3; 0];      % reference position
%u=@(X)-K*(X - wr);       % control law
%[t,X] = ode45(@(t,X)Nonlinear_Pendulum(X,m,M,L,g,u(X)),tspan,x0);

 %for k=1:75:length(t)
  % graphpend_m(X(k,:),m,M,L);
 %end
  %  subplot(4,1,2)
   % plot(t,X(:,3),'r','LineWidth',2)
    %xlabel('t [sec]')
    %ylabel('x [m]')
    %xlim([-10 12])
    %xticks(-10:1:12)
    %ylim([-4 4])
    %yticks(-4:1:4)
    %axis manual
    %grid on
    %subplot(4,1,3)
    %plot(t,X(:,1),'k','LineWidth',2)
    %xlabel('t [sec]')
    %ylabel('Theta [rad]')
    %xlim([-10 12])
    %xticks(-10:1:12)
    %ylim([-0.5 0.5])
    %yticks(-0.5:0.1:0.5)
    %axis manual
    %grid on
   
    %subplot(4,1,4)
    %plot(t,-K*transpose(X),'k','LineWidth',2)
    %xlabel('t [sec]')
    %ylabel('U [N]')
    %xlim([-10 12])
    %xticks(-10:1:12)
    %ylim([-40 40])
    %yticks(-40:6:40)
    %axis manual
    %grid on

