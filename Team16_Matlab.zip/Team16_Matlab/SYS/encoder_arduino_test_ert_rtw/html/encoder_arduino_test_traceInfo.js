function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "encoder_arduino_test"};
	this.sidHashMap["encoder_arduino_test"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/Gain"] = {sid: "encoder_arduino_test:5"};
	this.sidHashMap["encoder_arduino_test:5"] = {rtwname: "<Root>/Gain"};
	this.rtwnameHashMap["<Root>/MATLAB System"] = {sid: "encoder_arduino_test:1"};
	this.sidHashMap["encoder_arduino_test:1"] = {rtwname: "<Root>/MATLAB System"};
	this.rtwnameHashMap["<Root>/Scope"] = {sid: "encoder_arduino_test:6"};
	this.sidHashMap["encoder_arduino_test:6"] = {rtwname: "<Root>/Scope"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
