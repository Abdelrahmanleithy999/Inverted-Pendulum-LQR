function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["encoder_arduino_test.c:205c46"]=1;
    this.traceFlag["encoder_arduino_test.c:307c35"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["encoder_arduino_test.c:205"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:206"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:207"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:208"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:211"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:216"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:217"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:218"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:292"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:293"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:294"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:295"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:296"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:297"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:298"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:299"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:300"]=1;
    this.lineTraceFlag["encoder_arduino_test.c:307"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
