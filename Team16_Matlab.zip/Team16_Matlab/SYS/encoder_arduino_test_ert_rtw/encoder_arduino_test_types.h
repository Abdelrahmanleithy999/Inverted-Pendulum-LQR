/*
 * File: encoder_arduino_test_types.h
 *
 * Code generated for Simulink model 'encoder_arduino_test'.
 *
 * Model version                  : 1.10
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Wed Dec 28 18:30:52 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_encoder_arduino_test_types_h_
#define RTW_HEADER_encoder_arduino_test_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#ifndef typedef_Encoder_arduino_encoder_ardui_T
#define typedef_Encoder_arduino_encoder_ardui_T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  real_T SampleTime;
} Encoder_arduino_encoder_ardui_T;

#endif                               /*typedef_Encoder_arduino_encoder_ardui_T*/

/* Parameters (default storage) */
typedef struct P_encoder_arduino_test_T_ P_encoder_arduino_test_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_encoder_arduino_test_T RT_MODEL_encoder_arduino_test_T;

#endif                            /* RTW_HEADER_encoder_arduino_test_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
