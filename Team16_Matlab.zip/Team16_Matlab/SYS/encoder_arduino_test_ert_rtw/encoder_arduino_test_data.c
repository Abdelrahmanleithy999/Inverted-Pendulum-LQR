/*
 * File: encoder_arduino_test_data.c
 *
 * Code generated for Simulink model 'encoder_arduino_test'.
 *
 * Model version                  : 1.10
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Wed Dec 28 18:30:52 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "encoder_arduino_test.h"
#include "encoder_arduino_test_private.h"

/* Block parameters (default storage) */
P_encoder_arduino_test_T encoder_arduino_test_P = {
  /* Expression: 0.1
   * Referenced by: '<Root>/MATLAB System'
   */
  0.1,

  /* Computed Parameter: Gain_Gain
   * Referenced by: '<Root>/Gain'
   */
  1288490189
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
