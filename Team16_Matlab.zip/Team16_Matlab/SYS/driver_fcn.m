function [PWM , IN1 , IN2] = fcn(u)
PWM = (abs(u)*255)/7;
if u <0 
    IN1 = 1 ; IN2 = 0;
elseif u > 0 
    IN1 = 0 ; IN2 = 1;
else
    IN1 = 0 ; IN2 = 0;
    
end