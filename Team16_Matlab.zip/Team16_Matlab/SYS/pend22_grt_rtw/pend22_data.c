/*
 * pend22_data.c
 *
 * Code generation for model "pend22".
 *
 * Model version              : 21.6
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Wed Dec 28 19:11:42 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "pend22.h"
#include "pend22_private.h"

/* Block parameters (default storage) */
P_pend22_T pend22_P = {
  /* Variable: A
   * Referenced by: '<Root>/Furuta Pendulum'
   */
  { 0.0, 0.0, 0.0, 0.0, 1.0, 0.14294367892976589, 0.0, -0.89339799331103686, 0.0,
    38.386956521739137, 0.0, 122.62500000000001, 0.0, 0.0, 1.0, 0.0 },

  /* Variable: B
   * Referenced by: '<Root>/Furuta Pendulum'
   */
  { 0.0, 0.67745819397993312, 0.0, -4.2341137123745822 },

  /* Variable: k
   * Referenced by:
   *   '<S2>/K_1'
   *   '<S2>/K_2'
   *   '<S2>/K_3'
   *   '<S2>/K_4'
   */
  { -447.21359549995589, -406.02577082340821, -4246.2882597594225,
    -388.31189933271412 },

  /* Expression: 0
   * Referenced by: '<S5>/Digital Output'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S6>/Digital Output'
   */
  0.0,

  /* Expression: 0.1
   * Referenced by: '<S3>/MATLAB System1'
   */
  0.1,

  /* Expression: 0.1
   * Referenced by: '<S4>/MATLAB System'
   */
  0.1,

  /* Expression: eye(4)
   * Referenced by: '<Root>/Furuta Pendulum'
   */
  { 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
    1.0 },

  /* Expression: 0
   * Referenced by: '<Root>/Furuta Pendulum'
   */
  0.0,

  /* Computed Parameter: Delay_InitialCondition
   * Referenced by: '<S4>/Delay'
   */
  { { 0UL, 0UL } },

  /* Computed Parameter: Delay1_InitialCondition
   * Referenced by: '<S3>/Delay1'
   */
  { { 0UL, 0UL } },

  /* Computed Parameter: Gain3_Gain
   * Referenced by: '<S3>/Gain3'
   */
  { { 0UL, 0x50000000UL } },

  /* Computed Parameter: Gain1_Gain
   * Referenced by: '<S4>/Gain1'
   */
  { { 0UL, 0x50000000UL } },

  /* Computed Parameter: Gain_Gain
   * Referenced by: '<S4>/Gain'
   */
  1114263759,

  /* Computed Parameter: Gain2_Gain
   * Referenced by: '<S3>/Gain2'
   */
  1439257355,

  /* Computed Parameter: Delay1_DelayLength
   * Referenced by: '<S3>/Delay1'
   */
  1U,

  /* Computed Parameter: Delay_DelayLength
   * Referenced by: '<S4>/Delay'
   */
  1U
};
