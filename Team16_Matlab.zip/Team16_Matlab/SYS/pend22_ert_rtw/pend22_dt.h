/*
 * pend22_dt.h
 *
 * Code generation for model "pend22".
 *
 * Model version              : 21.12
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Mon Jan  2 14:47:55 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ext_types.h"

/* data type size table */
static uint_T rtDataTypeSizes[] = {
  sizeof(real_T),
  sizeof(real32_T),
  sizeof(int8_T),
  sizeof(uint8_T),
  sizeof(int16_T),
  sizeof(uint16_T),
  sizeof(int32_T),
  sizeof(uint32_T),
  sizeof(boolean_T),
  sizeof(fcn_call_T),
  sizeof(int_T),
  sizeof(pointer_T),
  sizeof(action_T),
  2*sizeof(uint32_T),
  sizeof(int32_T),
  sizeof(int64m_T),
  sizeof(int64m_T),
  sizeof(int128m_T),
  sizeof(int32_T),
  sizeof(int64m_T),
  sizeof(int64m_T),
  sizeof(int128m_T),
  sizeof(int128m_T),
  sizeof(codertarget_arduinobase_block_T),
  sizeof(codertarget_arduinobase_inter_T),
  sizeof(j_codertarget_arduinobase_int_T),
  sizeof(Encoder_arduino_pend22_T),
  sizeof(int64m_T),
  sizeof(uint64m_T),
  sizeof(int96m_T),
  sizeof(uint96m_T),
  sizeof(int128m_T),
  sizeof(uint128m_T),
  sizeof(int160m_T),
  sizeof(uint160m_T),
  sizeof(int192m_T),
  sizeof(uint192m_T),
  sizeof(int224m_T),
  sizeof(uint224m_T),
  sizeof(int256m_T),
  sizeof(uint256m_T)
};

/* data type name table */
static const char_T * rtDataTypeNames[] = {
  "real_T",
  "real32_T",
  "int8_T",
  "uint8_T",
  "int16_T",
  "uint16_T",
  "int32_T",
  "uint32_T",
  "boolean_T",
  "fcn_call_T",
  "int_T",
  "pointer_T",
  "action_T",
  "timer_uint32_pair_T",
  "int32_T",
  "int64m_T",
  "int64m_T",
  "int128m_T",
  "int32_T",
  "int64m_T",
  "int64m_T",
  "int128m_T",
  "int128m_T",
  "codertarget_arduinobase_block_T",
  "codertarget_arduinobase_inter_T",
  "j_codertarget_arduinobase_int_T",
  "Encoder_arduino_pend22_T",
  "int64m_T",
  "uint64m_T",
  "int96m_T",
  "uint96m_T",
  "int128m_T",
  "uint128m_T",
  "int160m_T",
  "uint160m_T",
  "int192m_T",
  "uint192m_T",
  "int224m_T",
  "uint224m_T",
  "int256m_T",
  "uint256m_T"
};

/* data type transitions for block I/O structure */
static DataTypeTransition rtBTransitions[] = {
  { (char_T *)(&pend22_B.Gain3), 21, 0, 1 },

  { (char_T *)(&pend22_B.alpha_1), 22, 0, 1 },

  { (char_T *)(&pend22_B.Gain2), 19, 0, 1 },

  { (char_T *)(&pend22_B.alpha), 15, 0, 1 },

  { (char_T *)(&pend22_B.DataTypeConversion2), 0, 0, 8 }
  ,

  { (char_T *)(&pend22_DW.obj), 24, 0, 1 },

  { (char_T *)(&pend22_DW.obj_k), 26, 0, 2 },

  { (char_T *)(&pend22_DW.gobj_1), 25, 0, 4 },

  { (char_T *)(&pend22_DW.obj_a), 23, 0, 2 },

  { (char_T *)(&pend22_DW.Delay_DSTATE), 15, 0, 1 },

  { (char_T *)(&pend22_DW.Delay1_DSTATE), 19, 0, 1 },

  { (char_T *)(&pend22_DW.Scope_PWORK.LoggedData[0]), 11, 0, 14 }
};

/* data type transition table for block I/O structure */
static DataTypeTransitionTable rtBTransTable = {
  12U,
  rtBTransitions
};

/* data type transitions for Parameters structure */
static DataTypeTransition rtPTransitions[] = {
  { (char_T *)(&pend22_P.k[0]), 0, 0, 4 },

  { (char_T *)(&pend22_P.Switch1_Threshold), 17, 0, 1 },

  { (char_T *)(&pend22_P.Constant1_Value), 0, 0, 6 },

  { (char_T *)(&pend22_P.Delay_InitialCondition), 15, 0, 2 },

  { (char_T *)(&pend22_P.Delay1_InitialCondition), 19, 0, 1 },

  { (char_T *)(&pend22_P.Gain3_Gain), 20, 0, 2 },

  { (char_T *)(&pend22_P.Gain_Gain), 16, 0, 1 },

  { (char_T *)(&pend22_P.Gain_Gain_i), 14, 0, 2 }
};

/* data type transition table for Parameters structure */
static DataTypeTransitionTable rtPTransTable = {
  8U,
  rtPTransitions
};

/* [EOF] pend22_dt.h */
