/*
 * File: pend22.c
 *
 * Code generated for Simulink model 'pend22'.
 *
 * Model version                  : 21.12
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Mon Jan  2 14:47:55 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "pend22.h"
#include "pend22_private.h"
#include "pend22_dt.h"

/* Block signals (default storage) */
B_pend22_T pend22_B;

/* Block states (default storage) */
DW_pend22_T pend22_DW;

/* Real-time model */
RT_MODEL_pend22_T pend22_M_;
RT_MODEL_pend22_T *const pend22_M = &pend22_M_;

/* Forward declaration for local functions */
static void matlabCodegenHandle_matlabC_op1(Encoder_arduino_pend22_T *obj);
static void pend22_SystemCore_release(codertarget_arduinobase_inter_T *obj);
static void pend22_SystemCore_delete_op(codertarget_arduinobase_inter_T *obj);
static void matlabCodegenHandle_matlabCo_op(codertarget_arduinobase_inter_T *obj);
static void matlabCodegenHandle_matlabCodeg(codertarget_arduinobase_block_T *obj);
static void arduino_PWMOutput_set_pinNumber(codertarget_arduinobase_inter_T *obj,
  j_codertarget_arduinobase_int_T *iobj_0);
void sMultiWordMul(const uint32_T u1[], int16_T n1, const uint32_T u2[], int16_T
                   n2, uint32_T y[], int16_T n)
{
  int16_T i;
  int16_T j;
  int16_T k;
  int16_T ni;
  uint32_T u1i;
  uint32_T yk;
  uint32_T a1;
  uint32_T a0;
  uint32_T b1;
  uint32_T w10;
  uint32_T w01;
  uint32_T cb;
  boolean_T isNegative1;
  boolean_T isNegative2;
  uint32_T cb1;
  uint32_T cb2;
  isNegative1 = ((u1[n1 - 1] & 2147483648UL) != 0UL);
  isNegative2 = ((u2[n2 - 1] & 2147483648UL) != 0UL);
  cb1 = 1UL;

  /* Initialize output to zero */
  for (k = 0; k < n; k++) {
    y[k] = 0UL;
  }

  for (i = 0; i < n1; i++) {
    cb = 0UL;
    u1i = u1[i];
    if (isNegative1) {
      u1i = ~u1i + cb1;
      cb1 = (uint32_T)(u1i < cb1);
    }

    a1 = u1i >> 16U;
    a0 = u1i & 65535UL;
    cb2 = 1UL;
    ni = n - i;
    ni = n2 <= ni ? n2 : ni;
    k = i;
    for (j = 0; j < ni; j++) {
      u1i = u2[j];
      if (isNegative2) {
        u1i = ~u1i + cb2;
        cb2 = (uint32_T)(u1i < cb2);
      }

      b1 = u1i >> 16U;
      u1i &= 65535UL;
      w10 = a1 * u1i;
      w01 = a0 * b1;
      yk = y[k] + cb;
      cb = (uint32_T)(yk < cb);
      u1i *= a0;
      yk += u1i;
      cb += (yk < u1i);
      u1i = w10 << 16U;
      yk += u1i;
      cb += (yk < u1i);
      u1i = w01 << 16U;
      yk += u1i;
      cb += (yk < u1i);
      y[k] = yk;
      cb += w10 >> 16U;
      cb += w01 >> 16U;
      cb += a1 * b1;
      k++;
    }

    if (k < n) {
      y[k] = cb;
    }
  }

  /* Apply sign */
  if (isNegative1 != isNegative2) {
    cb = 1UL;
    for (k = 0; k < n; k++) {
      yk = ~y[k] + cb;
      y[k] = yk;
      cb = (uint32_T)(yk < cb);
    }
  }
}

real_T sMultiWord2Double(const uint32_T u1[], int16_T n1, int16_T e1)
{
  real_T y;
  int16_T i;
  int16_T exp_0;
  uint32_T u1i;
  uint32_T cb;
  y = 0.0;
  exp_0 = e1;
  if ((u1[n1 - 1] & 2147483648UL) != 0UL) {
    cb = 1UL;
    for (i = 0; i < n1; i++) {
      u1i = ~u1[i];
      cb += u1i;
      y -= ldexp(cb, exp_0);
      cb = (uint32_T)(cb < u1i);
      exp_0 += 32;
    }
  } else {
    for (i = 0; i < n1; i++) {
      y += ldexp(u1[i], exp_0);
      exp_0 += 32;
    }
  }

  return y;
}

void MultiWordSub(const uint32_T u1[], const uint32_T u2[], uint32_T y[],
                  int16_T n)
{
  uint32_T yi;
  uint32_T u1i;
  uint32_T borrow = 0UL;
  int16_T i;
  for (i = 0; i < n; i++) {
    u1i = u1[i];
    yi = (u1i - u2[i]) - borrow;
    y[i] = yi;
    borrow = borrow != 0UL ? (uint32_T)(yi >= u1i) : (uint32_T)(yi > u1i);
  }
}

boolean_T sMultiWordGt(const uint32_T u1[], const uint32_T u2[], int16_T n)
{
  return sMultiWordCmp(u1, u2, n) > 0;
}

int16_T sMultiWordCmp(const uint32_T u1[], const uint32_T u2[], int16_T n)
{
  int16_T y;
  uint32_T u2i;
  uint32_T su1;
  int16_T i;
  su1 = u1[n - 1] & 2147483648UL;
  if ((u2[n - 1] & 2147483648UL) != su1) {
    y = su1 != 0UL ? -1 : 1;
  } else {
    y = 0;
    i = n;
    while ((y == 0) && (i > 0)) {
      i--;
      su1 = u1[i];
      u2i = u2[i];
      if (su1 != u2i) {
        y = su1 > u2i ? 1 : -1;
      }
    }
  }

  return y;
}

static void matlabCodegenHandle_matlabC_op1(Encoder_arduino_pend22_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
  }
}

static void pend22_SystemCore_release(codertarget_arduinobase_inter_T *obj)
{
  if ((obj->isInitialized == 1L) && obj->isSetupComplete) {
    obj->MW_PWM_HANDLE = MW_PWM_GetHandle(obj->PinPWM);
    MW_PWM_SetDutyCycle(obj->MW_PWM_HANDLE, 0.0);
    obj->MW_PWM_HANDLE = MW_PWM_GetHandle(obj->PinPWM);
    MW_PWM_Close(obj->MW_PWM_HANDLE);
  }
}

static void pend22_SystemCore_delete_op(codertarget_arduinobase_inter_T *obj)
{
  pend22_SystemCore_release(obj);
}

static void matlabCodegenHandle_matlabCo_op(codertarget_arduinobase_inter_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    pend22_SystemCore_delete_op(obj);
  }
}

static void matlabCodegenHandle_matlabCodeg(codertarget_arduinobase_block_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
  }
}

static void arduino_PWMOutput_set_pinNumber(codertarget_arduinobase_inter_T *obj,
  j_codertarget_arduinobase_int_T *iobj_0)
{
  iobj_0->AvailablePwmPinNames.f1 = '2';
  iobj_0->AvailablePwmPinNames.f2 = '3';
  iobj_0->AvailablePwmPinNames.f3 = '4';
  iobj_0->AvailablePwmPinNames.f4 = '5';
  iobj_0->AvailablePwmPinNames.f5 = '6';
  iobj_0->AvailablePwmPinNames.f6 = '7';
  iobj_0->AvailablePwmPinNames.f7 = '8';
  iobj_0->AvailablePwmPinNames.f8 = '9';
  iobj_0->AvailablePwmPinNames.f9[0] = '1';
  iobj_0->AvailablePwmPinNames.f9[1] = '0';
  iobj_0->AvailablePwmPinNames.f10[0] = '1';
  iobj_0->AvailablePwmPinNames.f10[1] = '1';
  iobj_0->AvailablePwmPinNames.f11[0] = '1';
  iobj_0->AvailablePwmPinNames.f11[1] = '2';
  iobj_0->AvailablePwmPinNames.f12[0] = '1';
  iobj_0->AvailablePwmPinNames.f12[1] = '3';
  obj->Hw = iobj_0;
  obj->PinPWM = 5UL;
}

/* Model step function */
void pend22_step(void)
{
  int32_T rtb_MATLABSystem1_0;
  codertarget_arduinobase_inter_T *obj;
  int16_T rtb_IN2;
  int16_T rtb_IN1;
  real_T rtb_PWM;
  uint32_T tmp;
  uint32_T tmp_0;
  int64m_T tmp_1;
  int128m_T tmp_2;
  int64m_T *tmp_3;

  /* MATLABSystem: '<S3>/MATLAB System1' */
  if (pend22_DW.obj_b.SampleTime != pend22_P.MATLABSystem1_SampleTime) {
    pend22_DW.obj_b.SampleTime = pend22_P.MATLABSystem1_SampleTime;
  }

  rtb_MATLABSystem1_0 = enc_output(0.0);

  /* Gain: '<S3>/Gain2' incorporates:
   *  MATLABSystem: '<S3>/MATLAB System1'
   */
  tmp = (uint32_T)pend22_P.Gain2_Gain;
  tmp_0 = (uint32_T)rtb_MATLABSystem1_0;
  sMultiWordMul(&tmp, 1, &tmp_0, 1, &pend22_B.Gain2.chunks[0U], 2);

  /* DataTypeConversion: '<S2>/Data Type Conversion2' */
  pend22_B.DataTypeConversion2 = sMultiWord2Double(&pend22_B.Gain2.chunks[0U], 2,
    0) * 1.8189894035458565E-12;

  /* Sum: '<S4>/Add' incorporates:
   *  Gain: '<S3>/Gain3'
   *  Gain: '<S4>/Gain'
   */
  pend22_B.alpha = pend22_P.Gain3_Gain;

  /* DataTypeConversion: '<S2>/Data Type Conversion2' incorporates:
   *  Sum: '<S3>/Add1'
   */
  tmp_3 = &pend22_B.Gain2;

  /* Sum: '<S3>/Add1' */
  MultiWordSub(&tmp_3->chunks[0U], &pend22_DW.Delay1_DSTATE.chunks[0U],
               &tmp_1.chunks[0U], 2);

  /* Gain: '<S3>/Gain3' */
  sMultiWordMul(&pend22_P.Gain3_Gain.chunks[0U], 2, &tmp_1.chunks[0U], 2,
                &pend22_B.Gain3.chunks[0U], 4);

  /* DataTypeConversion: '<S2>/Data Type Conversion3' */
  pend22_B.DataTypeConversion3 = sMultiWord2Double(&pend22_B.Gain3.chunks[0U], 4,
    0) * 3.1554436208840472E-30;

  /* MATLABSystem: '<S4>/MATLAB System' */
  if (pend22_DW.obj_k.SampleTime != pend22_P.MATLABSystem_SampleTime) {
    pend22_DW.obj_k.SampleTime = pend22_P.MATLABSystem_SampleTime;
  }

  rtb_MATLABSystem1_0 = enc_output(1.0);

  /* Gain: '<S4>/Gain' incorporates:
   *  MATLABSystem: '<S4>/MATLAB System'
   */
  tmp = (uint32_T)pend22_P.Gain_Gain_i;
  tmp_0 = (uint32_T)rtb_MATLABSystem1_0;
  sMultiWordMul(&tmp, 1, &tmp_0, 1, &pend22_B.alpha.chunks[0U], 2);

  /* DataTypeConversion: '<S2>/Data Type Conversion' */
  tmp_1 = pend22_B.alpha;
  pend22_B.DataTypeConversion = sMultiWord2Double(&tmp_1.chunks[0U], 2, 0) *
    3.637978807091713E-12;

  /* Sum: '<S4>/Add' */
  MultiWordSub(&pend22_B.alpha.chunks[0U], &pend22_DW.Delay_DSTATE.chunks[0U],
               &pend22_DW.Delay1_DSTATE.chunks[0U], 2);

  /* Gain: '<S4>/Gain1' */
  sMultiWordMul(&pend22_P.Gain1_Gain.chunks[0U], 2,
                &pend22_DW.Delay1_DSTATE.chunks[0U], 2,
                &pend22_B.alpha_1.chunks[0U], 4);

  /* DataTypeConversion: '<S2>/Data Type Conversion1' */
  pend22_B.DataTypeConversion1 = sMultiWord2Double(&pend22_B.alpha_1.chunks[0U],
    4, 0) * 6.3108872417680944E-30;

  /* Sum: '<S2>/Sum1' incorporates:
   *  Gain: '<S2>/K_1'
   *  Gain: '<S2>/K_2'
   *  Gain: '<S2>/K_3'
   *  Gain: '<S2>/K_4'
   */
  pend22_B.Sum1 = ((pend22_P.k[0] * 5.0 * pend22_B.DataTypeConversion2 +
                    pend22_P.k[1] / 10.0 * pend22_B.DataTypeConversion3) +
                   pend22_P.k[2] / 100.0 * pend22_B.DataTypeConversion) +
    pend22_P.k[3] / 10.0 * pend22_B.DataTypeConversion1;

  /* Sum: '<S4>/Add' incorporates:
   *  Sum: '<S3>/Add1'
   *  Switch: '<Root>/Switch'
   */
  tmp_3 = &pend22_B.alpha;

  /* Switch: '<Root>/Switch' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  if (sMultiWordGt(&tmp_3->chunks[0U], &pend22_P.Switch_Threshold_i.chunks[0U],
                   2)) {
    pend22_B.Switch = pend22_P.Constant2_Value;
  } else {
    pend22_B.Switch = pend22_B.Sum1;
  }

  /* Sum: '<S4>/Add' incorporates:
   *  Gain: '<Root>/Gain'
   */
  pend22_DW.Delay_DSTATE = pend22_B.alpha;

  /* Gain: '<Root>/Gain' */
  sMultiWordMul(&pend22_P.Gain_Gain.chunks[0U], 2,
                &pend22_DW.Delay_DSTATE.chunks[0U], 2, &tmp_2.chunks[0U], 4);

  /* Switch: '<Root>/Switch1' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  if (sMultiWordGt(&tmp_2.chunks[0U], &pend22_P.Switch1_Threshold.chunks[0U], 4))
  {
    pend22_B.Switch1 = pend22_P.Constant2_Value;
  } else {
    pend22_B.Switch1 = pend22_B.Switch;
  }

  /* End of Switch: '<Root>/Switch1' */

  /* MATLAB Function: '<S5>/MATLAB Function' */
  rtb_PWM = fabs(pend22_B.Switch1) * 255.0 / 2.0;
  if (pend22_B.Switch1 < 0.0) {
    rtb_IN1 = 0;
    rtb_IN2 = 1;
  } else if (pend22_B.Switch1 > 0.0) {
    rtb_IN1 = 1;
    rtb_IN2 = 0;
  } else {
    rtb_IN1 = 0;
    rtb_IN2 = 0;
  }

  /* End of MATLAB Function: '<S5>/MATLAB Function' */

  /* Switch: '<S1>/Switch' incorporates:
   *  Constant: '<S1>/Constant'
   *  Constant: '<S1>/Constant1'
   *  Sum: '<S1>/Add'
   */
  if (rtb_PWM > pend22_P.Switch_Threshold) {
    pend22_B.Switch_k = pend22_P.Constant_Value;
  } else {
    pend22_B.Switch_k = rtb_PWM + pend22_P.Constant1_Value;
  }

  /* End of Switch: '<S1>/Switch' */
  /* MATLABSystem: '<S1>/PWM' */
  obj = &pend22_DW.obj;
  obj->MW_PWM_HANDLE = MW_PWM_GetHandle(pend22_DW.obj.PinPWM);
  if (pend22_B.Switch_k < 255.0) {
    rtb_PWM = pend22_B.Switch_k;
  } else {
    rtb_PWM = 255.0;
  }

  if (!(rtb_PWM > 0.0)) {
    rtb_PWM = 0.0;
  }

  MW_PWM_SetDutyCycle(pend22_DW.obj.MW_PWM_HANDLE, rtb_PWM);

  /* End of MATLABSystem: '<S1>/PWM' */

  /* MATLABSystem: '<S1>/Digital Output' */
  writeDigitalPin(9, (uint8_T)rtb_IN1);

  /* MATLABSystem: '<S1>/Digital Output1' */
  writeDigitalPin(8, (uint8_T)rtb_IN2);

  /* Update for Sum: '<S3>/Add1' incorporates:
   *  Delay: '<S3>/Delay1'
   */
  pend22_DW.Delay1_DSTATE = pend22_B.Gain2;

  /* Update for Sum: '<S4>/Add' incorporates:
   *  Delay: '<S4>/Delay'
   */
  pend22_DW.Delay_DSTATE = pend22_B.alpha;

  /* External mode */
  rtExtModeUploadCheckTrigger(1);

  {                                    /* Sample time: [0.1s, 0.0s] */
    rtExtModeUpload(0, (real_T)pend22_M->Timing.taskTime0);
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.1s, 0.0s] */
    if ((rtmGetTFinal(pend22_M)!=-1) &&
        !((rtmGetTFinal(pend22_M)-pend22_M->Timing.taskTime0) >
          pend22_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(pend22_M, "Simulation finished");
    }

    if (rtmGetStopRequested(pend22_M)) {
      rtmSetErrorStatus(pend22_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  pend22_M->Timing.taskTime0 =
    ((time_T)(++pend22_M->Timing.clockTick0)) * pend22_M->Timing.stepSize0;
}

/* Model initialize function */
void pend22_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));
  rtmSetTFinal(pend22_M, -1);
  pend22_M->Timing.stepSize0 = 0.1;

  /* External mode info */
  pend22_M->Sizes.checksums[0] = (864286870U);
  pend22_M->Sizes.checksums[1] = (3947842905U);
  pend22_M->Sizes.checksums[2] = (3403818364U);
  pend22_M->Sizes.checksums[3] = (1097505421U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[9];
    pend22_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(pend22_M->extModeInfo,
      &pend22_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(pend22_M->extModeInfo, pend22_M->Sizes.checksums);
    rteiSetTPtr(pend22_M->extModeInfo, rtmGetTPtr(pend22_M));
  }

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    pend22_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 41;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  {
    codertarget_arduinobase_inter_T *obj;

    /* Start for MATLABSystem: '<S3>/MATLAB System1' */
    pend22_DW.obj_b.matlabCodegenIsDeleted = false;
    pend22_DW.obj_b.SampleTime = pend22_P.MATLABSystem1_SampleTime;
    pend22_DW.obj_b.isInitialized = 1L;
    enc_init(0.0, 2.0, 3.0);
    pend22_DW.obj_b.isSetupComplete = true;

    /* Start for MATLABSystem: '<S4>/MATLAB System' */
    pend22_DW.obj_k.matlabCodegenIsDeleted = false;
    pend22_DW.obj_k.SampleTime = pend22_P.MATLABSystem_SampleTime;
    pend22_DW.obj_k.isInitialized = 1L;
    enc_init(1.0, 20.0, 21.0);
    pend22_DW.obj_k.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/PWM' */
    pend22_DW.obj.matlabCodegenIsDeleted = true;
    pend22_DW.obj.isInitialized = 0L;
    pend22_DW.obj.matlabCodegenIsDeleted = false;
    arduino_PWMOutput_set_pinNumber(&pend22_DW.obj, &pend22_DW.gobj_2);
    obj = &pend22_DW.obj;
    pend22_DW.obj.isSetupComplete = false;
    pend22_DW.obj.isInitialized = 1L;
    obj->MW_PWM_HANDLE = MW_PWM_Open(pend22_DW.obj.PinPWM, 0.0, 0.0);
    obj->MW_PWM_HANDLE = MW_PWM_GetHandle(pend22_DW.obj.PinPWM);
    MW_PWM_Start(pend22_DW.obj.MW_PWM_HANDLE);
    pend22_DW.obj.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/Digital Output' */
    pend22_DW.obj_a.matlabCodegenIsDeleted = false;
    pend22_DW.obj_a.isInitialized = 1L;
    digitalIOSetup(9, 1);
    pend22_DW.obj_a.isSetupComplete = true;

    /* Start for MATLABSystem: '<S1>/Digital Output1' */
    pend22_DW.obj_d.matlabCodegenIsDeleted = false;
    pend22_DW.obj_d.isInitialized = 1L;
    digitalIOSetup(8, 1);
    pend22_DW.obj_d.isSetupComplete = true;

    /* InitializeConditions for Sum: '<S3>/Add1' incorporates:
     *  Delay: '<S3>/Delay1'
     */
    pend22_DW.Delay1_DSTATE = pend22_P.Delay1_InitialCondition;

    /* InitializeConditions for Sum: '<S4>/Add' incorporates:
     *  Delay: '<S4>/Delay'
     */
    pend22_DW.Delay_DSTATE = pend22_P.Delay_InitialCondition;
  }
}

/* Model terminate function */
void pend22_terminate(void)
{
  /* Terminate for MATLABSystem: '<S3>/MATLAB System1' */
  matlabCodegenHandle_matlabC_op1(&pend22_DW.obj_b);

  /* Terminate for MATLABSystem: '<S4>/MATLAB System' */
  matlabCodegenHandle_matlabC_op1(&pend22_DW.obj_k);

  /* Terminate for MATLABSystem: '<S1>/PWM' */
  matlabCodegenHandle_matlabCo_op(&pend22_DW.obj);

  /* Terminate for MATLABSystem: '<S1>/Digital Output' */
  matlabCodegenHandle_matlabCodeg(&pend22_DW.obj_a);

  /* Terminate for MATLABSystem: '<S1>/Digital Output1' */
  matlabCodegenHandle_matlabCodeg(&pend22_DW.obj_d);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
