/*
 * File: pend22.h
 *
 * Code generated for Simulink model 'pend22'.
 *
 * Model version                  : 21.12
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Mon Jan  2 14:47:55 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_pend22_h_
#define RTW_HEADER_pend22_h_
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef pend22_COMMON_INCLUDES_
# define pend22_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "dt_info.h"
#include "ext_work.h"
#include "MW_arduino_digitalio.h"
#include "MW_PWM.h"
#include "encoder_arduino.h"
#endif                                 /* pend22_COMMON_INCLUDES_ */

#include "pend22_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "MW_target_hardware_resources.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               (&(rtm)->Timing.taskTime0)
#endif

/* Block signals (default storage) */
typedef struct {
  int128m_T Gain3;                     /* '<S3>/Gain3' */
  int128m_T alpha_1;                   /* '<S4>/Gain1' */
  int64m_T Gain2;                      /* '<S3>/Gain2' */
  int64m_T alpha;                      /* '<S4>/Gain' */
  real_T DataTypeConversion2;          /* '<S2>/Data Type Conversion2' */
  real_T DataTypeConversion3;          /* '<S2>/Data Type Conversion3' */
  real_T DataTypeConversion;           /* '<S2>/Data Type Conversion' */
  real_T DataTypeConversion1;          /* '<S2>/Data Type Conversion1' */
  real_T Sum1;                         /* '<S2>/Sum1' */
  real_T Switch;                       /* '<Root>/Switch' */
  real_T Switch1;                      /* '<Root>/Switch1' */
  real_T Switch_k;                     /* '<S1>/Switch' */
} B_pend22_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  codertarget_arduinobase_inter_T obj; /* '<S1>/PWM' */
  Encoder_arduino_pend22_T obj_k;      /* '<S4>/MATLAB System' */
  Encoder_arduino_pend22_T obj_b;      /* '<S3>/MATLAB System1' */
  j_codertarget_arduinobase_int_T gobj_1;/* '<S1>/PWM' */
  j_codertarget_arduinobase_int_T gobj_2;/* '<S1>/PWM' */
  j_codertarget_arduinobase_int_T gobj_3;/* '<S1>/PWM' */
  j_codertarget_arduinobase_int_T gobj_4;/* '<S1>/PWM' */
  codertarget_arduinobase_block_T obj_a;/* '<S1>/Digital Output' */
  codertarget_arduinobase_block_T obj_d;/* '<S1>/Digital Output1' */
  int64m_T Delay_DSTATE;               /* '<S4>/Delay' */
  int64m_T Delay1_DSTATE;              /* '<S3>/Delay1' */
  struct {
    void *LoggedData[6];
  } Scope_PWORK;                       /* '<Root>/Scope' */

  struct {
    void *LoggedData;
  } alpha_dot_PWORK;                   /* '<S2>/alpha_dot' */

  struct {
    void *LoggedData[2];
  } Scope1_PWORK;                      /* '<S4>/Scope1' */

  struct {
    void *LoggedData;
  } alpha1_PWORK;                      /* '<S2>/alpha1' */

  struct {
    void *LoggedData;
  } theta_dot1_PWORK;                  /* '<S2>/theta_dot1' */

  struct {
    void *LoggedData[2];
  } Scope2_PWORK;                      /* '<S3>/Scope2' */

  struct {
    void *LoggedData;
  } theta1_PWORK;                      /* '<S2>/theta1' */
} DW_pend22_T;

/* Parameters (default storage) */
struct P_pend22_T_ {
  real_T k[4];                         /* Variable: k
                                        * Referenced by:
                                        *   '<S2>/K_1'
                                        *   '<S2>/K_2'
                                        *   '<S2>/K_3'
                                        *   '<S2>/K_4'
                                        */
  int128m_T Switch1_Threshold;         /* Computed Parameter: Switch1_Threshold
                                        * Referenced by: '<Root>/Switch1'
                                        */
  real_T Constant1_Value;              /* Expression: 10
                                        * Referenced by: '<S1>/Constant1'
                                        */
  real_T Constant_Value;               /* Expression: 200
                                        * Referenced by: '<S1>/Constant'
                                        */
  real_T MATLABSystem1_SampleTime;     /* Expression: 0.1
                                        * Referenced by: '<S3>/MATLAB System1'
                                        */
  real_T MATLABSystem_SampleTime;      /* Expression: 0.1
                                        * Referenced by: '<S4>/MATLAB System'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<Root>/Constant2'
                                        */
  real_T Switch_Threshold;             /* Expression: 200
                                        * Referenced by: '<S1>/Switch'
                                        */
  int64m_T Delay_InitialCondition; /* Computed Parameter: Delay_InitialCondition
                                    * Referenced by: '<S4>/Delay'
                                    */
  int64m_T Switch_Threshold_i;         /* Computed Parameter: Switch_Threshold_i
                                        * Referenced by: '<Root>/Switch'
                                        */
  int64m_T Delay1_InitialCondition;
                                  /* Computed Parameter: Delay1_InitialCondition
                                   * Referenced by: '<S3>/Delay1'
                                   */
  int64m_T Gain3_Gain;                 /* Computed Parameter: Gain3_Gain
                                        * Referenced by: '<S3>/Gain3'
                                        */
  int64m_T Gain1_Gain;                 /* Computed Parameter: Gain1_Gain
                                        * Referenced by: '<S4>/Gain1'
                                        */
  int64m_T Gain_Gain;                  /* Computed Parameter: Gain_Gain
                                        * Referenced by: '<Root>/Gain'
                                        */
  int32_T Gain_Gain_i;                 /* Computed Parameter: Gain_Gain_i
                                        * Referenced by: '<S4>/Gain'
                                        */
  int32_T Gain2_Gain;                  /* Computed Parameter: Gain2_Gain
                                        * Referenced by: '<S3>/Gain2'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_pend22_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_pend22_T pend22_P;

/* Block signals (default storage) */
extern B_pend22_T pend22_B;

/* Block states (default storage) */
extern DW_pend22_T pend22_DW;

/* Model entry point functions */
extern void pend22_initialize(void);
extern void pend22_step(void);
extern void pend22_terminate(void);

/* Real-time Model object */
extern RT_MODEL_pend22_T *const pend22_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'pend22'
 * '<S1>'   : 'pend22/Motor_driver'
 * '<S2>'   : 'pend22/Subsystem'
 * '<S3>'   : 'pend22/encoder  '
 * '<S4>'   : 'pend22/motor_encoder'
 * '<S5>'   : 'pend22/Motor_driver/Subsystem1'
 * '<S6>'   : 'pend22/Motor_driver/Subsystem1/MATLAB Function'
 */
#endif                                 /* RTW_HEADER_pend22_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
