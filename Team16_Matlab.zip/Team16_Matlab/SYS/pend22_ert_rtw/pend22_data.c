/*
 * File: pend22_data.c
 *
 * Code generated for Simulink model 'pend22'.
 *
 * Model version                  : 21.12
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Mon Jan  2 14:47:55 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "pend22.h"
#include "pend22_private.h"

/* Block parameters (default storage) */
P_pend22_T pend22_P = {
  /* Variable: k
   * Referenced by:
   *   '<S2>/K_1'
   *   '<S2>/K_2'
   *   '<S2>/K_3'
   *   '<S2>/K_4'
   */
  { -14.271585788535839, -2.3823294405467395, -40.516969432484423,
    -2.2710354562458281 },

  /* Computed Parameter: Switch1_Threshold
   * Referenced by: '<Root>/Switch1'
   */
  { { 0UL, 0UL, 0UL, 0x20UL } },

  /* Expression: 10
   * Referenced by: '<S1>/Constant1'
   */
  10.0,

  /* Expression: 200
   * Referenced by: '<S1>/Constant'
   */
  200.0,

  /* Expression: 0.1
   * Referenced by: '<S3>/MATLAB System1'
   */
  0.1,

  /* Expression: 0.1
   * Referenced by: '<S4>/MATLAB System'
   */
  0.1,

  /* Expression: 0
   * Referenced by: '<Root>/Constant2'
   */
  0.0,

  /* Expression: 200
   * Referenced by: '<S1>/Switch'
   */
  200.0,

  /* Computed Parameter: Delay_InitialCondition
   * Referenced by: '<S4>/Delay'
   */
  { { 0UL, 0UL } },

  /* Computed Parameter: Switch_Threshold_i
   * Referenced by: '<Root>/Switch'
   */
  { { 0UL, 0x80UL } },

  /* Computed Parameter: Delay1_InitialCondition
   * Referenced by: '<S3>/Delay1'
   */
  { { 0UL, 0UL } },

  /* Computed Parameter: Gain3_Gain
   * Referenced by: '<S3>/Gain3'
   */
  { { 0UL, 0x50000000UL } },

  /* Computed Parameter: Gain1_Gain
   * Referenced by: '<S4>/Gain1'
   */
  { { 0UL, 0x50000000UL } },

  /* Computed Parameter: Gain_Gain
   * Referenced by: '<Root>/Gain'
   */
  { { 0UL, 0x80000000UL } },

  /* Computed Parameter: Gain_Gain_i
   * Referenced by: '<S4>/Gain'
   */
  1114263759,

  /* Computed Parameter: Gain2_Gain
   * Referenced by: '<S3>/Gain2'
   */
  1439257355
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
